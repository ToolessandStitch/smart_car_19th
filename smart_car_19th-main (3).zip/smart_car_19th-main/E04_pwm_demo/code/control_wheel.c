#include "zf_common_headfile.h"
#include "zf_common_debug.h"
#include "isr.h"
#include "electrical_machine.h"
#include "efficient.h"
#include "pid.h"
#include "math.h"
#include "control_wheel.h"
//ת��
_pid turn_a,turn_b;
float turn_speed;
float snorlax,psyduck;
float speed_fl,speed_fr,speed_bl,speed_br; 
float PWM_front_left_camera,PWM_front_right_camera,PWM_down_left_camera,PWM_down_right_camera;
float PWM_front_left_camera_limit,PWM_front_right_camera_limit,PWM_down_left_camera_limit,PWM_down_right_camera_limit;
float limit_value(float num)
{
    if(num <0) 
		{
        return 10.0;
    } 
		else
		{
        return num;
    }
}
void motor_angle(float angle_turn) 
{
		PID_Data_Init(&turn_a);
		PID_Data_Init(&turn_a);
		PID_Param_Init(&turn_a,20000,1000);
		PID_Data_Init(&turn_b);
		PID_Data_Init(&turn_b);
		PID_Param_Init(&turn_b,20000,1000);
		turn_speed=PID_Calc(&turn_a,1,0,0,angle_turn,angle_pro_last);
		motor_control_pid(turn_speed,-turn_speed,turn_speed,-turn_speed);
} 
void motor_control_pid(int FL,int FR,int BL,int BR)
{
				PWM_front_left=PID_Calc(&speed_Front_left,35.5,0.05,0,(float)FL,(float)front_left_counts);

				PWM_front_right=PID_Calc(&speed_Front_right,35,0.03,0,(float)FR,(float)front_right_counts);
			
				PWM_down_left=PID_Calc(&speed_down_left,35,0.05,0,(float)BL,(float)down_left_counts);

				PWM_down_right=PID_Calc(&speed_down_right,37,0.05,0,(float)BR,(float)down_right_counts);
			
				motor_control(PWM_front_left,PWM_front_right,PWM_down_left,PWM_down_right);
	
}
void camera_control_pid(int FL,int FR,int BL,int BR,float Stitch,float exeggutor)
{
	 snorlax=PID_Calc(&toothless,170,0,1.35,188/2,Stitch);
   psyduck=PID_Calc(&physics,1,0,0,snorlax,exeggutor);
	if(Stitch<94) 
	{
		//masure PWM
       PWM_front_left=PID_Calc(&speed_Front_left,35.5,0.05,0,(float)FL,(float)front_left_counts);
       PWM_front_right=PID_Calc(&speed_Front_right,35,0.03,0,(float)FR,(float)front_right_counts);
			 PWM_down_left=PID_Calc(&speed_down_left,35,0.05,0,(float)BL,(float)down_left_counts);
	     PWM_down_right=PID_Calc(&speed_down_right,37,0.05,0,(float)BR,(float)down_right_counts);
		
		//PWM_chasu
	     PWM_front_left_camera=(PWM_front_left-snorlax*0.9);
		   PWM_front_right_camera=(PWM_front_right+snorlax*2.45);
		   PWM_down_left_camera=(PWM_down_left-snorlax*0.9);
		   PWM_down_right_camera=(PWM_down_right+snorlax*2.45);
		
		//PWM_set
	     motor_control(PWM_front_left_camera,PWM_front_right_camera,PWM_down_left_camera,PWM_down_right_camera);
	}
	if(Stitch>94) 
	{
	      PWM_front_left=PID_Calc(&speed_Front_left,35.5,0.05,0,(float)FL,(float)front_left_counts);
         PWM_front_right=PID_Calc(&speed_Front_right,35,0.03,0,(float)FR,(float)front_right_counts);
			  PWM_down_left=PID_Calc(&speed_down_left,35,0.05,0,(float)BL,(float)down_left_counts);
	      PWM_down_right=PID_Calc(&speed_down_right,37,0.05,0,(float)BR,(float)down_right_counts);
		
		
		    PWM_front_left_camera=(PWM_front_left-snorlax*1.2);
		    PWM_front_right_camera=(PWM_front_right+snorlax*0.9);
		    PWM_down_left_camera=(PWM_down_left-snorlax*1.2);
		    PWM_down_right_camera=(PWM_down_right+snorlax*0.9);

	      motor_control(PWM_front_left_camera,PWM_front_right_camera,PWM_down_left_camera,PWM_down_right_camera);
	}
}

void motor_control_road(int FL,int FR,int BL,int BR)
{
	
				//23,0.18,0     
				speed_front_left1=PID_Calc(&lfw,4,0.02,1.4,(float)FL,(float)front_left_road);
				PWM_front_left=PID_Calc(&speed_Front_left,3,0.01,0.9,(float)speed_front_left1,(float)front_left_counts);

				speed_front_right1=PID_Calc(&rfw,3.1,0.05,1.1,(float)FR,(float)front_right_road);
				PWM_front_right=PID_Calc(&speed_Front_right,4,0.012,0.6,(float)speed_front_right1,(float)front_right_counts);
			
				speed_down_left1=PID_Calc(&ldw,2.8,0.019,1.2,(float)BL,(float)down_left_road);
				PWM_down_left=PID_Calc(&speed_down_left,4,0,1.2,(float)speed_down_left1,(float)down_left_counts);
			
				speed_down_right1=PID_Calc(&rdw,3.3,0.08,1.25,(float)BR,(float)down_right_road);
				PWM_down_right=PID_Calc(&speed_down_right,3,0.02,0.9,(float)speed_down_right1,(float)down_right_counts);
			
				motor_control(PWM_front_left,PWM_front_right,PWM_down_left,PWM_down_right);
//zuo ping yi    -++-
}
void motor_road_clear()
{
			 front_left_road=0;
			 front_right_road=0;
			 down_left_road=0;
			 down_right_road=0;
}
/*
����������������
y�ᳯ��Ϊ���ϻ�����Ϊ0
x�ᳯ��Ϊ����������Ϊ0
z���ʾ����ĸ����̶�
										��y=0
					x<0				|      y<0
					y>0				|			 x<0
										|
										|
										|
	x=0��---------------------------��x=0
										|
					x>0				|			x>0
					y>0				|			y<0
										|
										|
										��y=0
*/